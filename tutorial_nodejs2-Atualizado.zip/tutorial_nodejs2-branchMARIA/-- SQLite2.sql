-- SQLite
-- Atualiza datas existentes para formato ISO
UPDATE posts 
SET datepost = 
    CASE 
        WHEN datepost LIKE 'Invalid Date%' THEN datetime('now')
        ELSE datetime(datepost) 
    END;