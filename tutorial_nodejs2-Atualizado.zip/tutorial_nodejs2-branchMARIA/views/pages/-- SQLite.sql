-- SQLite
ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'normal';